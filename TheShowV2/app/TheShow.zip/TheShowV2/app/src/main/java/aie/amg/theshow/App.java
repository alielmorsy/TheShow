package aie.amg.theshow;

import android.app.Application;

import com.google.android.gms.ads.MobileAds;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        MobileAds.initialize(this, "ca-app-pub-3924327175857175~1339730461");

    }
}
