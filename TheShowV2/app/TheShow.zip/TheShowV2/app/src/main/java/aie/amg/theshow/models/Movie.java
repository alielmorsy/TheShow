package aie.amg.theshow.models;

import java.io.Serializable;
import java.util.ArrayList;

public class Movie extends Show implements Serializable {
    private long duration;
    private String tokenID;
    private String downloadLink;
    public Movie(String name, String description, String type, long duration, String imageURL, float rating, int year, long numberDownloads, ArrayList<Actor> actors) {
        super(name, type, description, TYPE.MOVIE, rating, year, numberDownloads, imageURL, actors);
        this.duration = duration;
    }

    public Movie(String name, String type, String description, long duration, int reID, float rating, int year, long numberDownloads, ArrayList<Actor> actors) {
        super(name, type, description, reID, rating, year, numberDownloads, TYPE.MOVIE, actors);
        this.duration = duration;
    }

    public Movie() {
        super(TYPE.MOVIE);
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void setDuration(String duration) {
        this.duration = Long.parseLong(duration);
    }

    public String getTokenID() {
        return tokenID;
    }

    public void setTokenID(String tokenID) {
        this.tokenID = tokenID;
    }

    public String getDownloadLink() {
        return downloadLink;
    }

    public void setDownloadLink(String downloadLink) {
        this.downloadLink = downloadLink;
    }
}
