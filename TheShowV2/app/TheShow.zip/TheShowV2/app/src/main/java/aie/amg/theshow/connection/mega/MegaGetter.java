package aie.amg.theshow.connection.mega;

public class MegaGetter {
    public static String getLink() {

        return null;
    }
}
