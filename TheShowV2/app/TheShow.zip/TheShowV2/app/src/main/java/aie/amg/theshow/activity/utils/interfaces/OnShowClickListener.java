package aie.amg.theshow.activity.utils.interfaces;

import aie.amg.theshow.models.Show;

public interface OnShowClickListener {
    void onShowClickListener(Show show, int position);
}
