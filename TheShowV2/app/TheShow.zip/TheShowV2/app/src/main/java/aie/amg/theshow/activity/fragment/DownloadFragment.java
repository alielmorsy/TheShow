package aie.amg.theshow.activity.fragment;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.hendraanggrian.recyclerview.widget.ExpandableRecyclerView;

import aie.amg.theshow.R;
import aie.amg.theshow.models.Show;

public class DownloadFragment extends Fragment {

    public DownloadFragment() {
        super(R.layout.download_fragment);
    }

    public static DownloadFragment getInstance(Show show) {
        DownloadFragment fragment = new DownloadFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("show", show);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        AdView adView = view.findViewById(R.id.adView);
        adView.loadAd(new AdRequest.Builder().build());
        RecyclerView list = view.findViewById(R.id.list);
        LinearLayoutManager layout = new LinearLayoutManager(getContext());
        list.setLayoutManager(layout);

    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {

    }

    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {

    }
}
