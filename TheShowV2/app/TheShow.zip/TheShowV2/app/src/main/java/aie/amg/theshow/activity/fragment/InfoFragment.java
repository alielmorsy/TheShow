package aie.amg.theshow.activity.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import aie.amg.theshow.R;
import aie.amg.theshow.activity.InfoActivity;
import aie.amg.theshow.activity.TypeActivity;
import aie.amg.theshow.activity.utils.MainListAdapter;
import aie.amg.theshow.models.Movie;
import aie.amg.theshow.models.Series;
import aie.amg.theshow.models.Show;
import aie.amg.theshow.observers.ShowListObserver;
import aie.amg.theshow.util.Constants;
import aie.amg.theshow.util.JsonToModel;
import aie.amg.theshow.util.Utils;

public class InfoFragment extends Fragment {
    private Movie movie;
    private Series series;
    private int type;
    private Show show;
    private InterstitialAd ad;


    public InfoFragment() {
        super(R.layout.info_fragment);
    }

    public static InfoFragment getInstance(Show show) {
        InfoFragment fragment = new InfoFragment();
        Bundle bundle = new Bundle();
        bundle.putSerializable("show", show);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            show = (Show) getArguments().getSerializable("show");
        } else
            throw new IllegalArgumentException("None Show");
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {


        assert show != null : "Sorry show =null";
        show.addImage(view.findViewById(R.id.poster));
        TextView type1 = view.findViewById(R.id.type);
        if (show instanceof Series) {
            series = (Series) show;
            view.findViewById(R.id.series).setVisibility(View.VISIBLE);
            type = Constants.Series;
            TextView eCount = view.findViewById(R.id.episodeCount);
            eCount.setText(getString(R.string.episodes_count, series.getEpisodesCount()));
            TextView sCount = view.findViewById(R.id.seasons_count);
            sCount.setText(getString(R.string.seasons_count, series.getSessionCount()));
            type1.setText("مسلسل");
        } else {
            type = Constants.Movie;
            movie = (Movie) show;
            TextView duration = view.findViewById(R.id.duration);
            duration.setVisibility(View.VISIBLE);
            duration.setText(Utils.durationToMinutes(movie.getDuration()));
            type1.setText("فيلم");
        }
        TextView name = view.findViewById(R.id.name);
        name.setText(show.getName());

        TextView rating = view.findViewById(R.id.rating);
        rating.setText(String.valueOf(show.getRating()));

        TextView summary = view.findViewById(R.id.summary);
        summary.setText(show.getDescription());
        generateTypesList(view);
        getSimilar(view);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        loadAd(context);
    }

    private void generateTypesList(View view) {
        String types = show.getType().trim();
        types = types.replaceAll(" ", "");
        RecyclerView list = view.findViewById(R.id.typesList);
        StaggeredGridLayoutManager manager = new StaggeredGridLayoutManager(3, LinearLayout.VERTICAL);
        manager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS);
        list.setLayoutManager(manager);
        TypesAdapter adapter = new TypesAdapter(getContext(), types.split(","));
        adapter.onTypeClickListener = type -> {
            if (ad.isLoaded()) {
                ad.setAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
                        goFragment(type);
                    }
                });
                ad.show();
            } else {
                goFragment(type);
            }
        };
        list.setAdapter(adapter);
    }

    private void getSimilar(View view) {
        ShowListObserver observer = new ViewModelProvider(getViewModelStore(), getDefaultViewModelProviderFactory()).get(ShowListObserver.class);
        makeThread(observer);
        RecyclerView list = view.findViewById(R.id.similarList);
        MainListAdapter adapter = new MainListAdapter(getContext(), true);
        adapter.setOnShowClickListener(((show1, position) -> {
            startActivity(new Intent(getContext(), InfoActivity.class).putExtra("show", show));
        }));
        list.setAdapter(adapter);
        observer.getLiveData().observe(getViewLifecycleOwner(), shows -> {
            view.findViewById(R.id.progress).setVisibility(View.GONE);
            if (shows != null && shows.size() > 0) {
                list.setVisibility(View.VISIBLE);
                list.post(() -> adapter.setList(shows));
            } else
                view.findViewById(R.id.message).setVisibility(View.GONE);
        });
    }

    private void makeThread(ShowListObserver observer) {
        Runnable runnable = () -> {
            try {
                StringBuilder builder = new StringBuilder();
                String type = show.getsType() == Show.TYPE.SERIES ? "series" : "movies";
                URL url = new URL(Constants.URL + "GetList.php?what=similar&show=" + type + "&id=" + show.getId());

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(500);
                connection.setReadTimeout(500);
                InputStream stream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
                String line;
                while ((line = reader.readLine()) != null) {
                    builder.append(line).append("\n");
                }
                String text = builder.toString();
                if (type.equals("movies")) {
                    JsonToModel<Movie> toModel = new JsonToModel<>(text, Movie.class);
                    if (toModel.getType() == JsonToModel.JsonType.Error) {
                        observer.getLiveData().postValue(null);
                        return;
                    }
                    ArrayList<Show> shows = new ArrayList<>(toModel.getArray());
                    observer.getLiveData().postValue(shows);
                } else {
                    JsonToModel<Series> toModel = new JsonToModel<>(text, Series.class);
                    if (toModel.getType() == JsonToModel.JsonType.Error) {
                        observer.getLiveData().postValue(null);
                        return;
                    }
                    ArrayList<Show> shows = new ArrayList<>(toModel.getArray());
                    observer.getLiveData().postValue(shows);
                }
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
        };
        new Thread(runnable).start();
    }

    private void goFragment(String type) {
        startActivity(new Intent(getContext(), TypeActivity.class).putExtra("type", type));
    }

    private void loadAd(Context context) {
        ad = new InterstitialAd(context);
        ad.setAdUnitId("ca-app-pub-3924327175857175/3034334947");
        ad.loadAd(new AdRequest.Builder().build());
    }


    interface OnTypeClickListener {
        void onTypeClickListener(String type);
    }

    static class TypesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        String[] strings;
        OnTypeClickListener onTypeClickListener;
        private Context context;

        TypesAdapter(Context context, String[] strings) {
            this.context = context;
            this.strings = strings;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.types_item, parent, false);
            return new RecyclerView.ViewHolder(view) {
            };
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            TextView text = (TextView) holder.itemView;
            text.setOnClickListener((v) -> onTypeClickListener.onTypeClickListener(strings[position]));

            text.setText(strings[position]);
        }

        @Override
        public int getItemCount() {
            return strings.length;
        }

    }
}
