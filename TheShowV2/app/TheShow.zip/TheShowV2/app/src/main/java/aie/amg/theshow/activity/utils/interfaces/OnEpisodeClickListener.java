package aie.amg.theshow.activity.utils.interfaces;

import aie.amg.theshow.models.Series;

public interface OnEpisodeClickListener {

    void onEpisodeClickListener(Series.Episode episode, int position);
}
