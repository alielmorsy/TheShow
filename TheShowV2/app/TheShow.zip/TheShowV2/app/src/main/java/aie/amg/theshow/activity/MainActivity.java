package aie.amg.theshow.activity;

import android.app.DownloadManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.mikepenz.materialdrawer.AccountHeaderBuilder;
import com.mikepenz.materialdrawer.Drawer;
import com.mikepenz.materialdrawer.DrawerBuilder;
import com.mikepenz.materialdrawer.model.DividerDrawerItem;
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem;
import com.mikepenz.materialdrawer.model.SectionDrawerItem;
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem;

import java.util.ArrayList;
import java.util.List;

import aie.amg.theshow.R;
import aie.amg.theshow.activity.fragment.MainFragment;
import aie.amg.theshow.util.ConfigurationHelper;

public class MainActivity extends AppCompatActivity {
    private ConfigurationHelper confHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        confHelper = new ConfigurationHelper(this);
        setupSlider(toolbar);
        AdView adView = findViewById(R.id.adView);
        adView.loadAd(new AdRequest.Builder().build());

        addFragment(MainFragment.getInstance(MainFragment.MOVIES, MainFragment.news), "أفضل الأفلام");

    }

    private void setupSlider(Toolbar toolbar) {
        AccountHeaderBuilder headerBuilder = new AccountHeaderBuilder();
        headerBuilder.withActivity(this);
        headerBuilder.withHeaderBackground(R.drawable.logo);
        List<IDrawerItem> drawerItems = setupDrawerItems();

        new DrawerBuilder().withActivity(this).withToolbar(toolbar).withDrawerItems(drawerItems).withOnDrawerItemClickListener(new Drawer.OnDrawerItemClickListener() {
            @Override
            public boolean onItemClick(View view, int position, IDrawerItem drawerItem) {
                long identifier = drawerItem.getIdentifier();
                PrimaryDrawerItem pr = (PrimaryDrawerItem) drawerItem;
                String name = pr.getName().getText(getApplication());

                switch ((int) identifier) {
                    case 10:

                        addFragment(MainFragment.getInstance(MainFragment.MOVIES, MainFragment.news), "احدث اضافات الأفلام");
                        break;
                    case 11:
                        addFragment(MainFragment.getInstance(MainFragment.MOVIES, MainFragment.best), name);
                        break;
                    case 20:
                        addFragment(MainFragment.getInstance(MainFragment.SERIES, MainFragment.news), "أحدث المسلسلات");
                        break;
                    case 21:
                        addFragment(MainFragment.getInstance(MainFragment.SERIES, MainFragment.best), name);
                        break;
                    case 30:
                        addFragment(MainFragment.getInstance(MainFragment.EPISODES, MainFragment.news), name);
                        break;
                    case 1:
                        startActivity(new Intent(getApplicationContext(), AboutActivity.class));
                        break;
                    case 2:
                        startActivity(new Intent(getApplicationContext(), SettingsActivity.class));
                        break;
                    case 3:
                        startActivity(new Intent(getApplicationContext(),RequestActivity.class));
                        break;
                }

                return true;
            }
        }).withCloseOnClick(true)
                .withSliderBackgroundColorRes(R.color.background)
                .withAccountHeader(headerBuilder.build())
                .withSelectedItem(10).build();
    }

    private List<IDrawerItem> setupDrawerItems() {
        List<IDrawerItem> drawerItems = new ArrayList<>();
        //Movies
        SectionDrawerItem movies = new SectionDrawerItem().withName(R.string.moveis).withTextColorRes(R.color.primaryText);
        movies.withDivider(false);
        drawerItems.add(movies);
        PrimaryDrawerItem moviesNews = new PrimaryDrawerItem().withName(R.string.news)
                .withTextColorRes(R.color.primaryText).withSetSelected(true)
                .withSelectedColorRes(R.color.selected).withIcon(R.drawable.ic_news)
                .withSelectedIconColorRes(R.color.background).withIdentifier(10);
        drawerItems.add(moviesNews);

        drawerItems.add(new DividerDrawerItem());
        //Series
        SectionDrawerItem series = new SectionDrawerItem().withName(R.string.series).withSelectable(false).withTextColorRes(R.color.primaryText);
        series.withDivider(false);
        drawerItems.add(series);
        PrimaryDrawerItem seriesNews = new PrimaryDrawerItem().withName(R.string.news)
                .withTextColorRes(R.color.primaryText).withSelectable(true).withSetSelected(true)
                .withSelectedColorRes(R.color.selected).withIcon(R.drawable.ic_news)
                .withSelectedIconColorRes(R.color.background).withIdentifier(20);
        drawerItems.add(seriesNews);
        PrimaryDrawerItem episodes = new PrimaryDrawerItem().withName(R.string.new_episodes)
                .withTextColorRes(R.color.primaryText).withSelectable(true).withSetSelected(true)
                .withSelectedColorRes(R.color.selected).withIcon(R.drawable.ic_news)
                .withSelectedIconColorRes(R.color.background).withIdentifier(30);
        drawerItems.add(episodes);

        drawerItems.add(new DividerDrawerItem());
        //Others
        SectionDrawerItem list = new SectionDrawerItem().withName(R.string.drawer_list).withSelectable(false).withTextColorRes(R.color.primaryText);
        list.withDivider(false);
        drawerItems.add(list);
        PrimaryDrawerItem bestMovies = new PrimaryDrawerItem().withName(R.string.best_movies)
                .withTextColorRes(R.color.primaryText).withSelectable(true).withSetSelected(true)
                .withSelectedColorRes(R.color.selected).withIcon(R.drawable.ic_best)
                .withSelectedIconColorRes(R.color.background).withIdentifier(11);
        drawerItems.add(bestMovies);
        PrimaryDrawerItem bestSeries = new PrimaryDrawerItem().withName(R.string.best_series)
                .withTextColorRes(R.color.primaryText).withSelectable(true).withSetSelected(true)
                .withSelectedColorRes(R.color.selected).withIcon(R.drawable.ic_best)
                .withSelectedIconColorRes(R.color.background).withIdentifier(21);
        drawerItems.add(bestSeries);
        PrimaryDrawerItem suggestToday = new PrimaryDrawerItem().withName(R.string.suggest_today)
                .withTextColorRes(R.color.primaryText).withSelectable(true).withSetSelected(true)
                .withSelectedColorRes(R.color.selected).withIcon(R.drawable.ic_suggested)
                .withSelectedIconColorRes(R.color.background);
        drawerItems.add(suggestToday);
        drawerItems.add(new DividerDrawerItem());
        if (confHelper.isAnimationOpened())
            drawerItems.addAll(generateAnimSliding());

        SectionDrawerItem others = new SectionDrawerItem().withName(R.string.others).withSelectable(false).withTextColorRes(R.color.primaryText);
        list.withDivider(false);
        drawerItems.add(others);

        PrimaryDrawerItem request = new PrimaryDrawerItem().withName(R.string.request)
                .withTextColorRes(R.color.primaryText).withSelectable(true).withSetSelected(true).withIdentifier(3)
                .withSelectedColorRes(R.color.selected).withSelectedIconColorRes(R.color.background);
        drawerItems.add(request);

        PrimaryDrawerItem supportUs = new PrimaryDrawerItem().withName(R.string.support_us)
                .withTextColorRes(R.color.primaryText).withSelectable(true).withSetSelected(true).withIdentifier(4)
                .withSelectedColorRes(R.color.selected).withSelectedIconColorRes(R.color.background);
        drawerItems.add(supportUs);
        PrimaryDrawerItem aboutUS = new PrimaryDrawerItem().withName(R.string.about_us)
                .withTextColorRes(R.color.primaryText).withSelectable(true).withSetSelected(true).withIdentifier(1)
                .withSelectedColorRes(R.color.selected).withSelectedIconColorRes(R.color.background);
        drawerItems.add(aboutUS);
        PrimaryDrawerItem setting = new PrimaryDrawerItem().withName(R.string.settings)
                .withTextColorRes(R.color.primaryText).withSelectable(true).withSetSelected(true).withIdentifier(2)
                .withSelectedColorRes(R.color.selected).withSelectedIconColorRes(R.color.background);
        drawerItems.add(setting);

        return drawerItems;
    }

    private List<IDrawerItem> generateAnimSliding() {
        List<IDrawerItem> drawerItems = new ArrayList<>();
        SectionDrawerItem animy = new SectionDrawerItem().withName(R.string.animy).withSelectable(false).withTextColorRes(R.color.primaryText);
        animy.withDivider(false);

        drawerItems.add(animy);
        PrimaryDrawerItem animSeries = new PrimaryDrawerItem().withName(R.string.new_anim_series)
                .withTextColorRes(R.color.primaryText).withSelectable(true).withSetSelected(true)
                .withSelectedColorRes(R.color.selected).withIcon(R.drawable.ic_news)
                .withSelectedIconColorRes(R.color.background);
        drawerItems.add(animSeries);
        PrimaryDrawerItem animMovies = new PrimaryDrawerItem().withName(R.string.new_anim_movies)
                .withTextColorRes(R.color.primaryText).withSelectable(true).withSetSelected(true)
                .withSelectedColorRes(R.color.selected).withIcon(R.drawable.ic_news)
                .withSelectedIconColorRes(R.color.background);
        drawerItems.add(animMovies);
        drawerItems.add(new DividerDrawerItem());
        return drawerItems;
    }

    @Override
    protected void onResume() {
        super.onResume();
        InterstitialAd mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-3924327175857175/3034334947");

        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                mInterstitialAd.show();
            }
        });

    }

    private void addFragment(Fragment fragment, String name) {

        ActionBar bar = getSupportActionBar();
        if (bar != null) {
            bar.setTitle(name);
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.frame, fragment).commit();
    }
}
