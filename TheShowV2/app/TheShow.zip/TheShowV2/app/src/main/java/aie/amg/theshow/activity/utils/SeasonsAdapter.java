package aie.amg.theshow.activity.utils;

import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.thoughtbot.expandablerecyclerview.ExpandableRecyclerViewAdapter;
import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;
import com.thoughtbot.expandablerecyclerview.viewholders.GroupViewHolder;

import java.util.List;

public class SeasonsAdapter extends ExpandableRecyclerViewAdapter<SeasonsAdapter.SeasonViewHolder, SeasonsAdapter.EpisodeViewHolder> {


    public SeasonsAdapter(List<? extends ExpandableGroup> groups) {
        super(groups);
    }

    @Override
    public SeasonViewHolder onCreateGroupViewHolder(ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public EpisodeViewHolder onCreateChildViewHolder(ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindChildViewHolder(EpisodeViewHolder holder, int flatPosition, ExpandableGroup group, int childIndex) {

    }

    @Override
    public void onBindGroupViewHolder(SeasonViewHolder holder, int flatPosition, ExpandableGroup group) {

    }

    static class SeasonViewHolder extends GroupViewHolder {

     public SeasonViewHolder(@NonNull View itemView) {
         super(itemView);
     }
 }
 static class EpisodeViewHolder extends RecyclerView.ViewHolder{

     public EpisodeViewHolder(@NonNull View itemView) {
         super(itemView);
     }
 }
}
